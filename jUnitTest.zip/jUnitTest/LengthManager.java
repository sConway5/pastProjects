package jUnitTest;

public class LengthManager {

	int[] xCoordinates;
	int[] yCoordinates;

	/**
	 * Compares the length of the arrays of x and y coordinates to make sure they
	 * are the same.
	 * 
	 * @return
	 */
	public static boolean compareLength(int[] xCoords, int[] yCoords) {
		return false;
	}
}
