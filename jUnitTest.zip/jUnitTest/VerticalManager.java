package jUnitTest;

public class VerticalManager {

	public static boolean isStraightLine() {
		return false;
	}

	/**
	 * Takes
	 * 
	 * @param xCoordinates
	 * @return
	 */
	public static boolean isVertical(int[] xCoordinates) {
		if (isStraightLine()) {
			return false;
		}
		return true;
	}
}
