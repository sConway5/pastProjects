package jUnitTest;

public class HorizontalManager {

	public static boolean isStraightLine() {
		return false;
	}

	/**
	 * Takes in a set of y coordinates and returns true if the line is horizontal,
	 * false if it is not.
	 * 
	 * @return
	 */
	public static boolean isHorizontal(int[] yCoordinates) {
		if (isStraightLine()) {
			return false;
		}
		return true;
	}

}
