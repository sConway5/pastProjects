package jUnitTest;

public class SlopeManager {

	/**
	 * Takes in all of the y-coordinates of a given data set and takes the highest 3
	 * values. Lowers those 3 points proportionally to the other y-coordinates in
	 * order to flatten the curve.
	 * 
	 * @param yCoordinates
	 */
	public static int[] lowerSlope(int[] yCoordinates) {
		return null;
	}

}
