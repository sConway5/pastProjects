package jUnitTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;

import org.junit.jupiter.api.Test;

class TestUtilities {

	@Test
	public void badPathLoadFileLoadsNothing() {
		Utilities utility = new Utilities();
		File file = utility.loadFile("Z://somepaththatdoesntexist/");
		assertEquals(file, null);
	}

	@Test
	public void happyPathLoadFile() {
		Utilities utility = new Utilities();
		File file = utility.loadFile("C://Files/testfile.txt");
		// Note that assertEquals doesn't work in this case!
		assert (file != null);
	}

	@Test
	public void doubleOne() {
		Utilities utility = new Utilities();
		int d1 = utility.doubleNumber(1);
		assertEquals(d1, 2);
	}

	/**
	 * Values should be capped at Integer max
	 */
	@Test
	public void doubleLargeNumbers() {
		Utilities utility = new Utilities();
		int d1 = utility.doubleNumber(Integer.MAX_VALUE);
		assertEquals(d1, Integer.MAX_VALUE);
		d1 = utility.doubleNumber(Integer.MAX_VALUE / 2);
		assertEquals(d1, Integer.MAX_VALUE);
		d1 = utility.doubleNumber(Integer.MAX_VALUE / 2 - 1);
		assertEquals(d1, Integer.MAX_VALUE - 2);
	}

	/**
	 * Checks if the given data has more than one point.
	 * 
	 */
	@Test
	public void unhappyPathIsLine() {
		int[] xCoordinates = new int[1];
		int[] yCoordinates = new int[1];
		boolean isLine;
		if (xCoordinates.length <= 1 || yCoordinates.length <= 1) {
			isLine = false;
		} else {
			isLine = true;
		}
		assertEquals(isLine, true);
	}

	/**
	 * Checks if the given data has an equal amount of x and y coordinates. In this
	 * case they do.
	 */
	@Test
	public void happyPathEqualLength() {
		int[] xCoordinates = new int[10];
		int[] yCoordinates = new int[10];
		boolean actual = LengthManager.compareLength(xCoordinates, yCoordinates);
		assertEquals(actual, true);
	}

	/**
	 * Checks if the given data has an equal amount of x and y coordinates. In this
	 * case they do not.
	 */
	@Test
	public void unhappyPathEqualLength() {
		int[] xCoordinates = new int[10];
		int[] yCoordinates = new int[8];
		boolean actual = LengthManager.compareLength(xCoordinates, yCoordinates);
		assertEquals(actual, false);
	}

	/**
	 * Checks if the y values are the same throughout the data. In this case they
	 * are not, so it is not a horizontal line.
	 */
	@Test
	public void happyPathIsHorizontalLine() {
		int[] yPoints = { 1, 3, 5, 7, 9 };
		boolean actual = HorizontalManager.isHorizontal(yPoints);
		assertEquals(actual, false);
	}

	/**
	 * Checks if the y values are the same throughout the data. In this case they
	 * are, so it is a horizontal line.
	 */
	@Test
	public void unhappyPathIsHorizontalLine() {
		int[] yPoints = { 2, 2, 2, 2, 2 };
		boolean actual = HorizontalManager.isHorizontal(yPoints);
		assertEquals(actual, true);
	}

	/**
	 * Checks if the y values are the same throughout the data. In this case there
	 * are no x-points, so it is false.
	 */
	@Test
	public void emptyIsHorizontalLine() {
		int[] xPoints = {};
		boolean actual = HorizontalManager.isHorizontal(xPoints);
		assertEquals(actual, false);
	}

	/**
	 * Tests if the given data is a vertical line or not. In this case, it is.
	 */
	@Test
	public void unhappyPathIsVerticalLine() {
		int[] xPoints = { 0, 0, 0, 0, 0 };
		boolean actual = VerticalManager.isVertical(xPoints);
		assertEquals(actual, true);
	}

	/**
	 * Tests if the given data is a vertical line or not. In this case, it is not.
	 */
	@Test
	public void happyPathIsVerticalLine() {
		int[] xPoints = { 5, 1, 3, 7, 4 };
		boolean actual = VerticalManager.isVertical(xPoints);
		assertEquals(actual, false);
	}

	/**
	 * Checks if an empty set of ints is a vertical line, should return false in
	 * this case.
	 */
	@Test
	public void emptyIsVerticalLine() {
		int[] xPoints = {};
		boolean actual = VerticalManager.isVertical(xPoints);
		assertEquals(actual, false);
	}

	/**
	 * Tests if the slops is lowered after running the lower slope function on them.
	 */
	@Test
	public void happyPathLowerSlope() {
		int[] points = { 1, 2, 4, 6, 9 };
		int[] updatedPoints = SlopeManager.lowerSlope(points);
		assert (points != updatedPoints);

	}

}
